<?php
/**
 * Plugin Name: Fyremezzonine Conference Manager
 * Description: Adds conferences, conference metadata, public registration forms, and admin registration lists.
 * Version: 1.0.0
 * Author: Codex
 * Text Domain: fyremezzonine-manager
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FYREMEZZONINE_MANAGER_VERSION', '1.0.0');
define('FYREMEZZONINE_MANAGER_SCHEMA_VERSION', '1.5.0');

function fyremezzonine_manager_table_name() {
    global $wpdb;

    return $wpdb->prefix . 'conference_registrations';
}

function fyremezzonine_manager_partner_requests_table_name() {
    global $wpdb;

    return $wpdb->prefix . 'conference_partner_requests';
}

function fyremezzonine_manager_partnership_level_options() {
    return array(
        'general_partner' => 'Генеральный партнер',
        'partner' => 'Партнер',
        'media_partner' => 'Информационный партнер',
        'organizer' => 'Соорганизатор',
    );
}

function fyremezzonine_manager_partnership_level_label($level) {
    $options = fyremezzonine_manager_partnership_level_options();
    return $options[$level] ?? $options['partner'];
}

function fyremezzonine_manager_participant_type_options() {
    return array(
        'attendee' => 'Участвующий (слушатель)',
        'speaker' => 'Спикер',
        'coorganizer' => 'Соорганизатор',
        'exhibition' => 'Выставка',
        'mini_demo' => 'Мини-демонстрация (демонстрация на выставочном стенде)',
        'large_demo' => 'Крупномасштабная демонстрация',
    );
}

function fyremezzonine_manager_sanitize_participant_types($raw_types) {
    $raw_types = is_array($raw_types) ? $raw_types : array();
    $allowed = fyremezzonine_manager_participant_type_options();
    $types = array();

    foreach ($raw_types as $type) {
        $type = sanitize_key($type);
        if (isset($allowed[$type])) {
            $types[] = $type;
        }
    }

    return array_values(array_unique($types));
}

function fyremezzonine_manager_participant_types_label($types) {
    $options = fyremezzonine_manager_participant_type_options();
    $types = is_array($types) ? $types : array_filter(array_map('trim', explode(',', (string) $types)));
    $labels = array();

    foreach ($types as $type) {
        if (isset($options[$type])) {
            $labels[] = $options[$type];
        }
    }

    return implode(', ', $labels);
}

function fyremezzonine_manager_activate() {
    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();
    $table = fyremezzonine_manager_table_name();
    $partner_table = fyremezzonine_manager_partner_requests_table_name();

    $sql = "CREATE TABLE {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        conference_id bigint(20) unsigned NOT NULL,
        full_name varchar(190) NOT NULL,
        last_name varchar(190) NOT NULL DEFAULT '',
        first_name varchar(190) NOT NULL DEFAULT '',
        middle_name varchar(190) NOT NULL DEFAULT '',
        job_position varchar(190) NOT NULL DEFAULT '',
        email varchar(190) NOT NULL,
        phone varchar(60) NOT NULL DEFAULT '',
        organization varchar(190) NOT NULL DEFAULT '',
        participant_types text NULL,
        comment text NULL,
        privacy_consent tinyint(1) NOT NULL DEFAULT 0,
        status varchar(40) NOT NULL DEFAULT 'new',
        ip_address varchar(80) NOT NULL DEFAULT '',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY conference_id (conference_id),
        KEY email (email),
        KEY status (status),
        KEY created_at (created_at)
    ) {$charset_collate};";

    dbDelta($sql);

    $partner_sql = "CREATE TABLE {$partner_table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        conference_id bigint(20) unsigned NOT NULL DEFAULT 0,
        company_name varchar(190) NOT NULL,
        company_site varchar(190) NOT NULL DEFAULT '',
        company_city varchar(190) NOT NULL DEFAULT '',
        partnership_level varchar(80) NOT NULL DEFAULT 'partner',
        contact_name varchar(190) NOT NULL,
        contact_position varchar(190) NOT NULL DEFAULT '',
        email varchar(190) NOT NULL,
        phone varchar(60) NOT NULL DEFAULT '',
        comment text NULL,
        status varchar(40) NOT NULL DEFAULT 'new',
        ip_address varchar(80) NOT NULL DEFAULT '',
        created_at datetime NOT NULL,
        PRIMARY KEY  (id),
        KEY conference_id (conference_id),
        KEY email (email),
        KEY status (status),
        KEY created_at (created_at)
    ) {$charset_collate};";

    dbDelta($partner_sql);
    update_option('fyremezzonine_manager_schema_version', FYREMEZZONINE_MANAGER_SCHEMA_VERSION);
}
register_activation_hook(__FILE__, 'fyremezzonine_manager_activate');

function fyremezzonine_manager_maybe_upgrade_schema() {
    if (get_option('fyremezzonine_manager_schema_version') !== FYREMEZZONINE_MANAGER_SCHEMA_VERSION) {
        fyremezzonine_manager_activate();
    }
}
add_action('plugins_loaded', 'fyremezzonine_manager_maybe_upgrade_schema');

function fyremezzonine_manager_register_post_type() {
    register_post_type(
        'conference',
        array(
            'labels' => array(
                'name' => 'Конференции',
                'singular_name' => 'Конференция',
                'add_new_item' => 'Добавить конференцию',
                'edit_item' => 'Редактировать конференцию',
                'new_item' => 'Новая конференция',
                'view_item' => 'Посмотреть конференцию',
                'search_items' => 'Искать конференции',
                'not_found' => 'Конференции не найдены',
            ),
            'public' => true,
            'menu_icon' => 'dashicons-calendar-alt',
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'has_archive' => true,
            'rewrite' => array('slug' => 'conferences'),
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'fyremezzonine_manager_register_post_type');

function fyremezzonine_manager_meta_keys() {
    return array(
        '_conference_start_date' => array('label' => 'Дата начала', 'type' => 'date'),
        '_conference_end_date' => array('label' => 'Дата окончания', 'type' => 'date'),
        '_conference_city' => array('label' => 'Город', 'type' => 'text'),
        '_conference_venue' => array('label' => 'Место проведения', 'type' => 'text'),
        '_conference_registration_deadline' => array('label' => 'Дедлайн регистрации', 'type' => 'date'),
        '_conference_visual_theme' => array(
            'label' => 'Визуальная тема конференции',
            'type' => 'select',
            'options' => array(
                'classic' => 'Статья: светлая спокойная тема',
                'arctic' => 'Арктика: голубой фон, фиолетовые акценты, снежинки',
                'ember' => 'Дым и искры: темная жаркая тема',
            ),
        ),
        '_conference_program_url' => array('label' => 'Ссылка на программу', 'type' => 'url'),
        '_conference_chat_1_url' => array('label' => 'Ссылка на чат конференции', 'type' => 'url'),
        '_conference_hero_image_url' => array('label' => 'Фон/заставка первого экрана: изображение или GIF', 'type' => 'url'),
        '_conference_topic_intro' => array('label' => 'Описание блока тем', 'type' => 'textarea'),
        '_conference_topic_1_title' => array('label' => 'Тема 1: текст', 'type' => 'text'),
        '_conference_topic_1_image_url' => array('label' => 'Тема 1: изображение', 'type' => 'url'),
        '_conference_topic_2_title' => array('label' => 'Тема 2: текст', 'type' => 'text'),
        '_conference_topic_2_image_url' => array('label' => 'Тема 2: изображение', 'type' => 'url'),
        '_conference_topic_3_title' => array('label' => 'Тема 3: текст', 'type' => 'text'),
        '_conference_topic_3_image_url' => array('label' => 'Тема 3: изображение', 'type' => 'url'),
        '_conference_about_title' => array('label' => 'Заголовок блока "О конференции"', 'type' => 'text'),
        '_conference_about_lead' => array('label' => 'Лид блока "О конференции"', 'type' => 'textarea'),
        '_conference_benefits' => array('label' => 'Преимущества/тезисы: по одному пункту на строку', 'type' => 'textarea'),
        '_conference_speakers' => array('label' => 'Спикеры конференции', 'type' => 'speakers'),
        '_conference_venue_heading' => array('label' => 'Заголовок блока места проведения', 'type' => 'text'),
        '_conference_venue_intro' => array('label' => 'Описание места проведения', 'type' => 'textarea'),
        '_conference_route_address' => array('label' => 'Адрес для карты/маршрута', 'type' => 'text'),
        '_conference_route_directions' => array('label' => 'Как добраться: текст маршрута', 'type' => 'textarea'),
        '_conference_map_lat' => array('label' => 'Широта метки карты', 'type' => 'text'),
        '_conference_map_lon' => array('label' => 'Долгота метки карты', 'type' => 'text'),
        '_conference_venue_image_url' => array('label' => 'Фото под картой 1: файл изображения', 'type' => 'url'),
        '_conference_collage_image_url' => array('label' => 'Фото под картой 2: файл изображения', 'type' => 'url'),
        '_conference_organizers' => array('label' => 'Организаторы', 'type' => 'partners'),
        '_conference_general_partners' => array('label' => 'Генеральные партнеры', 'type' => 'partners'),
        '_conference_partners' => array('label' => 'Партнеры', 'type' => 'partners'),
        '_conference_media_partners' => array('label' => 'Информационные партнеры', 'type' => 'partners'),
        '_conference_topics' => array('label' => 'Темы конференции', 'type' => 'topics'),
    );
}

function fyremezzonine_manager_hidden_editor_meta_keys() {
    return array(
        '_conference_map_lat',
        '_conference_map_lon',
    );
}

function fyremezzonine_manager_partner_meta_keys() {
    return array(
        '_conference_organizers',
        '_conference_general_partners',
        '_conference_partners',
        '_conference_media_partners',
    );
}

function fyremezzonine_manager_image_meta_keys() {
    return array(
        '_conference_hero_image_url',
        '_conference_topic_1_image_url',
        '_conference_topic_2_image_url',
        '_conference_topic_3_image_url',
        '_conference_venue_image_url',
        '_conference_collage_image_url',
    );
}

function fyremezzonine_manager_upload_image_for_field($field_name, $post_id = 0) {
    $file_key = $field_name . '_file';

    if (empty($_FILES[$file_key]) || !isset($_FILES[$file_key]['error']) || (int) $_FILES[$file_key]['error'] === UPLOAD_ERR_NO_FILE) {
        return '';
    }

    if ((int) $_FILES[$file_key]['error'] !== UPLOAD_ERR_OK) {
        return '';
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $attachment_id = media_handle_upload($file_key, $post_id);

    if (is_wp_error($attachment_id)) {
        return '';
    }

    return wp_get_attachment_url($attachment_id) ?: '';
}

function fyremezzonine_manager_repeater_file_count($file_key) {
    if (empty($_FILES[$file_key]) || empty($_FILES[$file_key]['name']) || !is_array($_FILES[$file_key]['name'])) {
        return 0;
    }

    return count($_FILES[$file_key]['name']);
}

function fyremezzonine_manager_upload_repeater_image_for_field($file_key, $index, $post_id = 0) {
    if (empty($_FILES[$file_key]) || empty($_FILES[$file_key]['name']) || !is_array($_FILES[$file_key]['name'])) {
        return '';
    }

    if (empty($_FILES[$file_key]['name'][$index])) {
        return '';
    }

    $error = isset($_FILES[$file_key]['error'][$index]) ? (int) $_FILES[$file_key]['error'][$index] : UPLOAD_ERR_NO_FILE;
    if ($error === UPLOAD_ERR_NO_FILE || $error !== UPLOAD_ERR_OK) {
        return '';
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $single_file_key = $file_key . '_' . $index . '_upload';
    $_FILES[$single_file_key] = array(
        'name' => $_FILES[$file_key]['name'][$index],
        'type' => $_FILES[$file_key]['type'][$index] ?? '',
        'tmp_name' => $_FILES[$file_key]['tmp_name'][$index] ?? '',
        'error' => $error,
        'size' => $_FILES[$file_key]['size'][$index] ?? 0,
    );

    $attachment_id = media_handle_upload($single_file_key, $post_id);
    unset($_FILES[$single_file_key]);

    if (is_wp_error($attachment_id)) {
        return '';
    }

    return wp_get_attachment_url($attachment_id) ?: '';
}

function fyremezzonine_manager_render_uploaded_image_preview($image_url, $label = 'Загруженное изображение') {
    if (!$image_url) {
        return;
    }

    ?>
    <figure class="conference-upload-preview">
        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($label); ?>" loading="lazy" onerror="this.closest('.conference-upload-preview').classList.add('conference-upload-preview-broken'); this.remove();">
        <figcaption>
            <span class="conference-upload-preview-error">Изображение не загрузилось. Проверьте ссылку или загрузите файл заново.</span>
            <a href="<?php echo esc_url($image_url); ?>" target="_blank" rel="noopener">Открыть файл</a>
        </figcaption>
    </figure>
    <?php
}

function fyremezzonine_manager_parse_partner_rows($raw) {
    $items = array();

    foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $raw))) as $line) {
        $parts = array_map('trim', explode('|', $line));
        if (empty($parts[0])) {
            continue;
        }

        $items[] = array(
            'name' => $parts[0],
            'url' => $parts[1] ?? '',
            'logo_url' => $parts[2] ?? '',
        );
    }

    return $items;
}

function fyremezzonine_manager_partner_rows_from_request($key, $post_id = 0) {
    $names = isset($_POST[$key . '_name']) && is_array($_POST[$key . '_name']) ? wp_unslash($_POST[$key . '_name']) : array();
    $urls = isset($_POST[$key . '_url']) && is_array($_POST[$key . '_url']) ? wp_unslash($_POST[$key . '_url']) : array();
    $logos = isset($_POST[$key . '_logo_url']) && is_array($_POST[$key . '_logo_url']) ? wp_unslash($_POST[$key . '_logo_url']) : array();
    $file_key = $key . '_logo_url_file';
    $rows = array();
    $total = max(count($names), count($urls), count($logos), fyremezzonine_manager_repeater_file_count($file_key));

    for ($index = 0; $index < $total; $index++) {
        $name = isset($names[$index]) ? sanitize_text_field($names[$index]) : '';
        $url = isset($urls[$index]) ? esc_url_raw($urls[$index]) : '';
        $uploaded_logo_url = fyremezzonine_manager_upload_repeater_image_for_field($file_key, $index, $post_id);
        $logo_url = $uploaded_logo_url ?: (isset($logos[$index]) ? esc_url_raw($logos[$index]) : '');

        if (!$name && !$url && !$logo_url) {
            continue;
        }

        if (!$name) {
            $name = $key === '_conference_organizers' ? 'Организатор конференции' : 'Партнер конференции';
        }

        $rows[] = $name . ' | ' . $url . ' | ' . $logo_url;
    }

    return implode("\n", $rows);
}

function fyremezzonine_manager_parse_topic_rows($raw) {
    $items = array();

    foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $raw))) as $line) {
        $parts = array_map('trim', explode('|', $line));
        if (empty($parts[0])) {
            continue;
        }

        $items[] = array(
            'title' => $parts[0],
            'image_url' => $parts[1] ?? '',
        );
    }

    return $items;
}

function fyremezzonine_manager_topic_rows_from_request($key, $post_id = 0) {
    $titles = isset($_POST[$key . '_title']) && is_array($_POST[$key . '_title']) ? wp_unslash($_POST[$key . '_title']) : array();
    $images = isset($_POST[$key . '_image_url']) && is_array($_POST[$key . '_image_url']) ? wp_unslash($_POST[$key . '_image_url']) : array();
    $file_key = $key . '_image_url_file';
    $rows = array();
    $total = max(count($titles), count($images), fyremezzonine_manager_repeater_file_count($file_key));

    for ($index = 0; $index < $total; $index++) {
        $title = isset($titles[$index]) ? sanitize_text_field($titles[$index]) : '';
        $uploaded_image_url = fyremezzonine_manager_upload_repeater_image_for_field($file_key, $index, $post_id);
        $image_url = $uploaded_image_url ?: (isset($images[$index]) ? esc_url_raw($images[$index]) : '');

        if (!$title && !$image_url) {
            continue;
        }

        if (!$title) {
            $title = 'Тема конференции';
        }

        $rows[] = $title . ' | ' . $image_url;
    }

    return implode("\n", $rows);
}

function fyremezzonine_manager_parse_speaker_rows($raw) {
    $items = array();

    foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $raw))) as $line) {
        $parts = array_map('trim', explode('|', $line));
        if (empty($parts[0])) {
            continue;
        }

        $items[] = array(
            'name' => $parts[0],
            'position' => $parts[1] ?? '',
            'quote' => $parts[2] ?? '',
            'photo_url' => $parts[3] ?? '',
            'direction' => $parts[4] ?? '',
        );
    }

    return $items;
}

function fyremezzonine_manager_speaker_rows_from_request($key, $post_id = 0) {
    $names = isset($_POST[$key . '_name']) && is_array($_POST[$key . '_name']) ? wp_unslash($_POST[$key . '_name']) : array();
    $positions = isset($_POST[$key . '_position']) && is_array($_POST[$key . '_position']) ? wp_unslash($_POST[$key . '_position']) : array();
    $directions = isset($_POST[$key . '_direction']) && is_array($_POST[$key . '_direction']) ? wp_unslash($_POST[$key . '_direction']) : array();
    $quotes = isset($_POST[$key . '_quote']) && is_array($_POST[$key . '_quote']) ? wp_unslash($_POST[$key . '_quote']) : array();
    $photos = isset($_POST[$key . '_photo_url']) && is_array($_POST[$key . '_photo_url']) ? wp_unslash($_POST[$key . '_photo_url']) : array();
    $file_key = $key . '_photo_url_file';
    $rows = array();
    $total = max(count($names), count($positions), count($directions), count($quotes), count($photos), fyremezzonine_manager_repeater_file_count($file_key));

    for ($index = 0; $index < $total; $index++) {
        $name = isset($names[$index]) ? sanitize_text_field($names[$index]) : '';
        $position = isset($positions[$index]) ? sanitize_text_field($positions[$index]) : '';
        $direction = isset($directions[$index]) ? sanitize_text_field($directions[$index]) : '';
        $quote = isset($quotes[$index]) ? sanitize_text_field($quotes[$index]) : '';
        $uploaded_photo_url = fyremezzonine_manager_upload_repeater_image_for_field($file_key, $index, $post_id);
        $photo_url = $uploaded_photo_url ?: (isset($photos[$index]) ? esc_url_raw($photos[$index]) : '');

        if (!$name && !$position && !$direction && !$quote && !$photo_url) {
            continue;
        }

        if (!$name) {
            $name = 'Спикер конференции';
        }

        $rows[] = $name . ' | ' . $position . ' | ' . $quote . ' | ' . $photo_url . ' | ' . $direction;
    }

    return implode("\n", $rows);
}

function fyremezzonine_manager_render_partner_repeater_assets() {
    static $rendered = false;

    if ($rendered) {
        return;
    }

    $rendered = true;
    ?>
    <style>
        .conference-partner-repeater {
            display: grid;
            gap: 14px;
            min-width: 0;
            margin: 0 0 18px;
        }
        .conference-partner-rows {
            display: grid;
            gap: 14px;
            counter-reset: conference-partner;
        }
        .conference-partner-row {
            display: grid;
            gap: 14px;
            min-width: 0;
            padding: 16px;
            border: 1px solid #dcdcde;
            border-radius: 8px;
            background: #fff;
            box-shadow: 0 10px 24px rgba(16, 24, 40, 0.06);
            counter-increment: conference-partner;
        }
        .conference-partner-row-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            min-width: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #f0f0f1;
        }
        .conference-partner-row-title {
            min-width: 0;
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }
        .conference-partner-row-title::after {
            content: counter(conference-partner);
            display: inline-grid;
            min-width: 24px;
            height: 24px;
            margin-left: 8px;
            place-items: center;
            border-radius: 999px;
            color: #fff;
            background: #525afc;
            font-size: 12px;
        }
        .conference-partner-fields {
            display: grid;
            grid-template-columns: 1fr;
            gap: 12px;
            min-width: 0;
        }
        .conference-partner-row label {
            display: grid;
            gap: 6px;
            min-width: 0;
            margin: 0;
            font-weight: 600;
        }
        .conference-partner-row label span {
            color: #1d2327;
            font-size: 13px;
            overflow-wrap: anywhere;
        }
        .conference-partner-row input {
            width: 100%;
            min-width: 0;
        }
        .conference-upload-preview {
            display: grid;
            gap: 7px;
            justify-self: center;
            width: min(280px, 100%);
            margin: 6px auto;
            padding: 10px;
            border: 1px solid #dcdcde;
            border-radius: 8px;
            background: #f6f7f7;
        }
        .conference-upload-preview img {
            width: 100%;
            max-height: 150px;
            object-fit: contain;
            border-radius: 8px;
            background: #fff;
        }
        .conference-upload-preview figcaption {
            color: #646970;
            font-size: 12px;
            line-height: 1.3;
            text-align: center;
        }
        .conference-upload-preview-error {
            display: none;
            margin-bottom: 4px;
            color: #b32d2e;
            font-weight: 700;
        }
        .conference-upload-preview-broken .conference-upload-preview-error {
            display: block;
        }
        .conference-partner-repeater template {
            display: none;
        }
        @media (max-width: 900px) {
            .conference-partner-fields {
                grid-template-columns: 1fr;
            }
            .conference-partner-row-head {
                align-items: flex-start;
                flex-direction: column;
            }
        }
    </style>
    <script>
        document.addEventListener('click', function(event) {
            const addButton = event.target.closest('[data-repeater-add]');
            if (addButton) {
                const repeater = addButton.closest('[data-repeater]');
                const rows = repeater.querySelector('[data-repeater-rows]');
                const template = repeater.querySelector('template');
                rows.insertAdjacentHTML('beforeend', template.innerHTML);
            }

            const removeButton = event.target.closest('[data-repeater-remove]');
            if (removeButton) {
                removeButton.closest('[data-repeater-row]').remove();
            }
        });
    </script>
    <?php
}

function fyremezzonine_manager_render_partner_repeater($key, $label, $value = '') {
    $items = fyremezzonine_manager_parse_partner_rows($value);
    if (!$items) {
        $items = array(array('name' => '', 'url' => '', 'logo_url' => ''));
    }

    $entity_title = $key === '_conference_organizers' ? 'Организатор' : 'Партнер';
    $add_button_label = $key === '_conference_organizers' ? '+ Добавить организатора' : '+ Добавить партнера';

    $render_row = static function($item) use ($key, $entity_title) {
        ?>
        <div class="conference-partner-row" data-repeater-row>
            <div class="conference-partner-row-head">
                <strong class="conference-partner-row-title"><?php echo esc_html($entity_title); ?></strong>
                <button type="button" class="button conference-partner-remove" data-repeater-remove>Удалить</button>
            </div>
            <div class="conference-partner-fields">
                <label>
                    <span>Название компании</span>
                    <input type="text" name="<?php echo esc_attr($key); ?>_name[]" value="<?php echo esc_attr($item['name'] ?? ''); ?>" placeholder="Например: Fireproff">
                </label>
                <label>
                    <span>Ссылка на сайт партнера</span>
                    <input type="url" name="<?php echo esc_attr($key); ?>_url[]" value="<?php echo esc_attr($item['url'] ?? ''); ?>" placeholder="https://example.ru/">
                </label>
                <label>
                    <span>Иконка/логотип</span>
                    <input type="hidden" name="<?php echo esc_attr($key); ?>_logo_url[]" value="<?php echo esc_attr($item['logo_url'] ?? ''); ?>">
                    <?php if (!empty($item['logo_url'])) : ?>
                        <?php fyremezzonine_manager_render_uploaded_image_preview($item['logo_url'], 'Логотип ' . ($item['name'] ?? 'организации')); ?>
                        <small>Файл уже загружен. Чтобы заменить, выберите новый.</small>
                    <?php endif; ?>
                    <input type="file" name="<?php echo esc_attr($key); ?>_logo_url_file[]" accept="image/*,.gif">
                </label>
            </div>
        </div>
        <?php
    };

    echo '<div class="conference-submission-field conference-partner-repeater" data-repeater>';
    echo '<div class="conference-partner-repeater-head">';
    printf('<label>%s</label>', esc_html($label));
    echo '<p class="conference-submission-note">Можно оставить список пустым. Каждая карточка - одна организация с названием, сайтом и логотипом.</p>';
    echo '</div>';
    echo '<div class="conference-partner-rows" data-repeater-rows>';
    foreach ($items as $item) {
        $render_row($item);
    }
    echo '</div>';
    printf('<button type="button" class="button conference-partner-add" data-repeater-add>%s</button>', esc_html($add_button_label));
    echo '<template>';
    $render_row(array('name' => '', 'url' => '', 'logo_url' => ''));
    echo '</template>';
    echo '</div>';

    fyremezzonine_manager_render_partner_repeater_assets();
}

function fyremezzonine_manager_partner_template_meta_keys() {
    return array(
        '_conference_organizers',
        '_conference_general_partners',
        '_conference_partners',
        '_conference_media_partners',
    );
}

function fyremezzonine_manager_topic_template_meta_keys() {
    return array(
        '_conference_topic_intro',
        '_conference_topics',
    );
}

function fyremezzonine_manager_conference_has_partner_template($conference_id) {
    foreach (fyremezzonine_manager_partner_template_meta_keys() as $meta_key) {
        if (trim((string) get_post_meta($conference_id, $meta_key, true)) !== '') {
            return true;
        }
    }

    return false;
}

function fyremezzonine_manager_conference_has_topic_template($conference_id) {
    foreach (fyremezzonine_manager_topic_template_meta_keys() as $meta_key) {
        if (trim((string) get_post_meta($conference_id, $meta_key, true)) !== '') {
            return true;
        }
    }

    return false;
}

function fyremezzonine_manager_latest_template_conference_id($has_template_callback, $exclude_id = 0) {
    $conferences = get_posts(
        array(
            'post_type' => 'conference',
            'post_status' => array('publish', 'draft', 'future', 'private'),
            'numberposts' => -1,
            'meta_key' => '_conference_start_date',
            'orderby' => 'meta_value',
            'order' => 'DESC',
            'fields' => 'ids',
        )
    );

    foreach ($conferences as $conference_id) {
        $conference_id = absint($conference_id);
        if ($conference_id === absint($exclude_id)) {
            continue;
        }

        if (call_user_func($has_template_callback, $conference_id)) {
            return $conference_id;
        }
    }

    $fallback_conferences = get_posts(
        array(
            'post_type' => 'conference',
            'post_status' => array('publish', 'draft', 'future', 'private'),
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'fields' => 'ids',
        )
    );

    foreach ($fallback_conferences as $conference_id) {
        $conference_id = absint($conference_id);
        if ($conference_id === absint($exclude_id)) {
            continue;
        }

        if (call_user_func($has_template_callback, $conference_id)) {
            return $conference_id;
        }
    }

    return 0;
}

function fyremezzonine_manager_latest_partner_template_conference_id($exclude_id = 0) {
    return fyremezzonine_manager_latest_template_conference_id('fyremezzonine_manager_conference_has_partner_template', $exclude_id);
}

function fyremezzonine_manager_latest_topic_template_conference_id($exclude_id = 0) {
    return fyremezzonine_manager_latest_template_conference_id('fyremezzonine_manager_conference_has_topic_template', $exclude_id);
}

function fyremezzonine_manager_render_topic_repeater($key, $label, $value = '') {
    $items = fyremezzonine_manager_parse_topic_rows($value);
    if (!$items) {
        $items = array(array('title' => '', 'image_url' => ''));
    }

    $render_row = static function($item) use ($key) {
        ?>
        <div class="conference-partner-row conference-topic-row" data-repeater-row>
            <div class="conference-partner-row-head">
                <strong class="conference-partner-row-title">Тема</strong>
                <button type="button" class="button conference-partner-remove" data-repeater-remove>Удалить</button>
            </div>
            <div class="conference-partner-fields">
                <label>
                    <span>Название темы</span>
                    <input type="text" name="<?php echo esc_attr($key); ?>_title[]" value="<?php echo esc_attr($item['title'] ?? ''); ?>" placeholder="Например: Предупреждение техногенных катастроф">
                </label>
                <label>
                    <span>Изображение темы</span>
                    <input type="hidden" name="<?php echo esc_attr($key); ?>_image_url[]" value="<?php echo esc_attr($item['image_url'] ?? ''); ?>">
                    <?php if (!empty($item['image_url'])) : ?>
                        <?php fyremezzonine_manager_render_uploaded_image_preview($item['image_url'], 'Изображение темы'); ?>
                        <small>Файл уже загружен. Чтобы заменить, выберите новый.</small>
                    <?php endif; ?>
                    <input type="file" name="<?php echo esc_attr($key); ?>_image_url_file[]" accept="image/*,.gif">
                </label>
            </div>
        </div>
        <?php
    };

    echo '<div class="conference-submission-field conference-partner-repeater conference-topic-repeater" data-repeater>';
    echo '<div class="conference-partner-repeater-head">';
    printf('<label>%s</label>', esc_html($label));
    echo '<p class="conference-submission-note">Добавьте столько тем, сколько нужно. Каждая карточка - одна тема с текстом и изображением.</p>';
    echo '</div>';
    echo '<div class="conference-partner-rows" data-repeater-rows>';
    foreach ($items as $item) {
        $render_row($item);
    }
    echo '</div>';
    echo '<button type="button" class="button conference-partner-add" data-repeater-add>+ Добавить тему</button>';
    echo '<template>';
    $render_row(array('title' => '', 'image_url' => ''));
    echo '</template>';
    echo '</div>';

    fyremezzonine_manager_render_partner_repeater_assets();
}

function fyremezzonine_manager_render_speaker_repeater($key, $label, $value = '') {
    $items = fyremezzonine_manager_parse_speaker_rows($value);
    if (!$items) {
        $items = array(array('name' => '', 'position' => '', 'direction' => '', 'quote' => '', 'photo_url' => ''));
    }

    $render_row = static function($item) use ($key) {
        ?>
        <div class="conference-partner-row conference-speaker-row" data-repeater-row>
            <div class="conference-partner-row-head">
                <strong class="conference-partner-row-title">Спикер</strong>
                <button type="button" class="button conference-partner-remove" data-repeater-remove>Удалить</button>
            </div>
            <div class="conference-partner-fields conference-speaker-fields">
                <label>
                    <span>Фото спикера</span>
                    <input type="hidden" name="<?php echo esc_attr($key); ?>_photo_url[]" value="<?php echo esc_attr($item['photo_url'] ?? ''); ?>">
                    <?php if (!empty($item['photo_url'])) : ?>
                        <?php fyremezzonine_manager_render_uploaded_image_preview($item['photo_url'], 'Фото спикера'); ?>
                        <small>Файл уже загружен. Чтобы заменить, выберите новый.</small>
                    <?php endif; ?>
                    <input type="file" name="<?php echo esc_attr($key); ?>_photo_url_file[]" accept="image/*,.gif">
                </label>
                <label>
                    <span>Имя и фамилия</span>
                    <input type="text" name="<?php echo esc_attr($key); ?>_name[]" value="<?php echo esc_attr($item['name'] ?? ''); ?>" placeholder="Например: Иван Петров">
                </label>
                <label>
                    <span>Должность</span>
                    <input type="text" name="<?php echo esc_attr($key); ?>_position[]" value="<?php echo esc_attr($item['position'] ?? ''); ?>" placeholder="Например: руководитель направления">
                </label>
                <label>
                    <span>Направление научного доклада</span>
                    <input type="text" name="<?php echo esc_attr($key); ?>_direction[]" value="<?php echo esc_attr($item['direction'] ?? ''); ?>" placeholder="Например: мониторинг техногенных рисков">
                </label>
                <label>
                    <span>Выдержка из слов</span>
                    <textarea name="<?php echo esc_attr($key); ?>_quote[]" rows="3" placeholder="Короткая цитата или тезис выступления"><?php echo esc_textarea($item['quote'] ?? ''); ?></textarea>
                </label>
            </div>
        </div>
        <?php
    };

    echo '<div class="conference-submission-field conference-partner-repeater conference-speaker-repeater" data-repeater>';
    echo '<div class="conference-partner-repeater-head">';
    printf('<label>%s</label>', esc_html($label));
    echo '<p class="conference-submission-note">Добавьте спикеров конференции: фото, имя, должность, направление научного доклада и короткую цитату.</p>';
    echo '</div>';
    echo '<div class="conference-partner-rows" data-repeater-rows>';
    foreach ($items as $item) {
        $render_row($item);
    }
    echo '</div>';
    echo '<button type="button" class="button conference-partner-add" data-repeater-add>+ Добавить спикера</button>';
    echo '<template>';
    $render_row(array('name' => '', 'position' => '', 'direction' => '', 'quote' => '', 'photo_url' => ''));
    echo '</template>';
    echo '</div>';

    fyremezzonine_manager_render_partner_repeater_assets();
}

function fyremezzonine_manager_add_meta_boxes() {
    add_meta_box(
        'fyremezzonine_conference_details',
        'Данные конференции',
        'fyremezzonine_manager_render_meta_box',
        'conference',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'fyremezzonine_manager_add_meta_boxes');

function fyremezzonine_manager_render_meta_box($post) {
    wp_nonce_field('fyremezzonine_manager_save_meta', 'fyremezzonine_manager_meta_nonce');

    echo '<p><em>Эти поля управляют главной страницей, страницей конференции, формой регистрации и атмосферой события. Изображения загружаются через кнопку выбора файла.</em></p>';

    $image_fields = fyremezzonine_manager_image_meta_keys();

    $hidden_fields = fyremezzonine_manager_hidden_editor_meta_keys();

    foreach (fyremezzonine_manager_meta_keys() as $key => $field) {
        if (in_array($key, $hidden_fields, true)) {
            continue;
        }

        $value = get_post_meta($post->ID, $key, true);
        echo '<p>';
        printf('<label for="%1$s"><strong>%2$s</strong></label><br>', esc_attr($key), esc_html($field['label']));

        if (in_array($key, $image_fields, true)) {
            printf('<input type="hidden" id="%1$s" name="%1$s" value="%2$s">', esc_attr($key), esc_attr($value));
            if ($value) {
                fyremezzonine_manager_render_uploaded_image_preview($value, $field['label']);
                printf('<span class="description">Текущий файл: <a href="%1$s" target="_blank" rel="noopener">открыть</a></span><br>', esc_url($value));
            }
            printf(
                '<label for="%1$s_file">Выбрать файл</label><br><input type="file" id="%1$s_file" name="%1$s_file" accept="image/*,.gif" class="widefat">',
                esc_attr($key)
            );
            echo '</p>';
            continue;
        }

        if ($field['type'] === 'partners') {
            echo '</p>';
            fyremezzonine_manager_render_partner_repeater($key, $field['label'], $value);
            continue;
        }

        if ($field['type'] === 'select') {
            printf('<select id="%1$s" name="%1$s" class="widefat">', esc_attr($key));
            foreach ($field['options'] as $option_value => $option_label) {
                printf(
                    '<option value="%1$s"%3$s>%2$s</option>',
                    esc_attr($option_value),
                    esc_html($option_label),
                    selected($value ?: 'classic', $option_value, false)
                );
            }
            echo '</select>';
        } elseif ($field['type'] === 'textarea') {
            printf(
                '<textarea id="%1$s" name="%1$s" rows="4" class="widefat">%2$s</textarea>',
                esc_attr($key),
                esc_textarea($value)
            );
        } else {
            printf(
                '<input type="%1$s" id="%2$s" name="%2$s" value="%3$s" class="widefat">',
                esc_attr($field['type']),
                esc_attr($key),
                esc_attr($value)
            );
        }

        echo '</p>';
    }
}

function fyremezzonine_manager_save_meta($post_id) {
    if (!isset($_POST['fyremezzonine_manager_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fyremezzonine_manager_meta_nonce'])), 'fyremezzonine_manager_save_meta')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    foreach (fyremezzonine_manager_meta_keys() as $key => $field) {
        if ($field['type'] === 'partners') {
            update_post_meta($post_id, $key, fyremezzonine_manager_partner_rows_from_request($key, $post_id));
            continue;
        }
        if ($field['type'] === 'topics') {
            update_post_meta($post_id, $key, fyremezzonine_manager_topic_rows_from_request($key, $post_id));
            continue;
        }
        if ($field['type'] === 'speakers') {
            update_post_meta($post_id, $key, fyremezzonine_manager_speaker_rows_from_request($key, $post_id));
            continue;
        }

        if (!isset($_POST[$key])) {
            update_post_meta($post_id, $key, '');
            continue;
        }

        $uploaded_url = in_array($key, fyremezzonine_manager_image_meta_keys(), true) ? fyremezzonine_manager_upload_image_for_field($key, $post_id) : '';
        if ($uploaded_url) {
            update_post_meta($post_id, $key, esc_url_raw($uploaded_url));
            continue;
        }

        $raw_value = wp_unslash($_POST[$key]);
        if ($field['type'] === 'textarea') {
            $value = sanitize_textarea_field($raw_value);
        } elseif ($field['type'] === 'url') {
            $value = esc_url_raw($raw_value);
        } elseif ($field['type'] === 'select') {
            $value = fyremezzonine_manager_sanitize_select_value($raw_value, $field);
        } else {
            $value = sanitize_text_field($raw_value);
        }

        update_post_meta($post_id, $key, $value);
    }
}
add_action('save_post_conference', 'fyremezzonine_manager_save_meta');

function fyremezzonine_manager_post_edit_form_tag() {
    global $post;

    if ($post && $post->post_type === 'conference') {
        echo ' enctype="multipart/form-data"';
    }
}
add_action('post_edit_form_tag', 'fyremezzonine_manager_post_edit_form_tag');

function fyremezzonine_manager_submission_field_groups() {
    return array(
        'event' => array(
            'title' => 'Основные данные',
            'description' => 'То, что посетитель увидит в заголовке и кратком описании конференции.',
            'fields' => array(
                'conference_title' => array('label' => 'Название конференции', 'type' => 'text', 'required' => true),
                'conference_excerpt' => array('label' => 'Краткое описание', 'type' => 'textarea'),
                'conference_content' => array('label' => 'Полное описание', 'type' => 'textarea'),
            ),
        ),
        'schedule' => array(
            'title' => 'Даты и место',
            'description' => 'Эти поля управляют карточкой события, регистрацией и блоком места проведения.',
            'fields' => array(
                '_conference_start_date',
                '_conference_end_date',
                '_conference_city',
                '_conference_venue',
                '_conference_registration_deadline',
                '_conference_visual_theme',
                '_conference_route_address',
                '_conference_route_directions',
            ),
        ),
        'content' => array(
            'title' => 'Содержимое страницы',
            'description' => 'Тексты для тематических блоков, материалов и раздела "О конференции".',
            'fields' => array(
                '_conference_topic_intro',
                '_conference_topics',
                '_conference_about_title',
                '_conference_about_lead',
                '_conference_benefits',
                '_conference_speakers',
            ),
        ),
        'links' => array(
            'title' => 'Ссылки, изображения и карта',
            'description' => 'Ссылки вводятся текстом, изображения загружаются через выбор файла.',
            'fields' => array(
                '_conference_program_url',
                '_conference_chat_1_url',
                '_conference_hero_image_url',
                '_conference_venue_heading',
                '_conference_venue_intro',
            ),
        ),
        'venue_photos' => array(
            'title' => 'Фотографии под картой',
            'description' => 'Эти два изображения показываются сразу под Яндекс.Картой. Выберите файлы с компьютера.',
            'fields' => array(
                '_conference_venue_image_url',
                '_conference_collage_image_url',
            ),
        ),
        'partners' => array(
            'title' => 'Спонсоры и партнеры',
            'description' => 'Добавляйте организации карточками: название, сайт и логотип. Список можно оставить пустым.',
            'fields' => array(
                '_conference_organizers',
                '_conference_general_partners',
                '_conference_partners',
                '_conference_media_partners',
            ),
        ),
    );
}

function fyremezzonine_manager_sanitize_submission_value($value, $type) {
    $raw_value = wp_unslash($value);

    if ($type === 'partners') {
        return sanitize_textarea_field($raw_value);
    }

    if ($type === 'topics') {
        return sanitize_textarea_field($raw_value);
    }

    if ($type === 'speakers') {
        return sanitize_textarea_field($raw_value);
    }

    if ($type === 'textarea') {
        return sanitize_textarea_field($raw_value);
    }

    if ($type === 'url') {
        return esc_url_raw($raw_value);
    }

    return sanitize_text_field($raw_value);
}

function fyremezzonine_manager_sanitize_select_value($value, $field) {
    $raw_value = sanitize_key(wp_unslash($value));

    return isset($field['options'][$raw_value]) ? $raw_value : 'classic';
}

function fyremezzonine_manager_submission_placeholder($name) {
    $placeholders = array(
        'conference_title' => 'Например: Предупреждение техногенных катастроф',
        'conference_excerpt' => 'Коротко опишите конференцию в 1-2 предложениях',
        'conference_content' => 'Полное описание, которое увидит посетитель',
        '_conference_city' => 'Например: Оренбург',
        '_conference_venue' => 'Например: испытательный полигон ВНИИПО',
        '_conference_route_address' => 'Например: Нижняя Павловка, Полигонная улица, д. 1',
        '_conference_route_directions' => 'Кратко опишите, как добраться до места проведения',
        '_conference_visual_theme' => '',
        '_conference_program_url' => 'https://...',
        '_conference_chat_1_url' => 'https://...',
        '_conference_hero_image_url' => 'https://.../hero.gif',
        '_conference_topic_1_image_url' => 'https://.../image.jpg',
        '_conference_topic_2_image_url' => 'https://.../image.jpg',
        '_conference_topic_3_image_url' => 'https://.../image.jpg',
        '_conference_map_lat' => '51.768199',
        '_conference_map_lon' => '55.096955',
        '_conference_venue_image_url' => 'https://.../photo.jpg',
        '_conference_collage_image_url' => 'https://.../photo.jpg',
    );

    return $placeholders[$name] ?? '';
}

function fyremezzonine_manager_render_submission_field($name, $field, $value = '') {
    $required = !empty($field['required']) ? ' required' : '';
    $label = isset($field['label']) ? $field['label'] : $name;
    $type = isset($field['type']) ? $field['type'] : 'text';
    $is_image_field = in_array($name, fyremezzonine_manager_image_meta_keys(), true);
    $placeholder = fyremezzonine_manager_submission_placeholder($name);

    if ($type === 'partners') {
        fyremezzonine_manager_render_partner_repeater($name, $label, $value);
        return;
    }

    if ($type === 'topics') {
        fyremezzonine_manager_render_topic_repeater($name, $label, $value);
        return;
    }

    if ($type === 'speakers') {
        fyremezzonine_manager_render_speaker_repeater($name, $label, $value);
        return;
    }

    echo '<p class="conference-submission-field">';
    printf('<label for="%1$s">%2$s</label>', esc_attr($name), esc_html($label));

    if ($is_image_field) {
        printf('<input id="%1$s" type="hidden" name="%1$s" value="%2$s">', esc_attr($name), esc_attr($value));
        if ($value) {
            fyremezzonine_manager_render_uploaded_image_preview($value, $label);
            printf('<span class="conference-submission-note">Текущий файл уже загружен: <a href="%1$s" target="_blank" rel="noopener">открыть</a>. Чтобы заменить его, выберите новый файл ниже.</span>', esc_url($value));
        } else {
            echo '<span class="conference-submission-note">Выберите изображение с компьютера. Для заставки первого экрана можно выбрать GIF.</span>';
        }
        printf(
            '<input id="%1$s_file" type="file" name="%1$s_file" accept="image/*,.gif">',
            esc_attr($name)
        );
        echo '</p>';
        return;
    }

    if ($type === 'select') {
        printf('<select id="%1$s" name="%1$s"%2$s>', esc_attr($name), $required);
        foreach ($field['options'] as $option_value => $option_label) {
            printf(
                '<option value="%1$s"%3$s>%2$s</option>',
                esc_attr($option_value),
                esc_html($option_label),
                selected($value ?: 'classic', $option_value, false)
            );
        }
        echo '</select>';
    } elseif ($type === 'textarea') {
        printf(
            '<textarea id="%1$s" name="%1$s" rows="4" placeholder="%4$s"%3$s>%2$s</textarea>',
            esc_attr($name),
            esc_textarea($value),
            $required,
            esc_attr($placeholder)
        );
    } else {
        printf(
            '<input id="%1$s" type="%2$s" name="%1$s" value="%3$s" placeholder="%5$s"%4$s>',
            esc_attr($name),
            esc_attr($type),
            esc_attr($value),
            $required,
            esc_attr($placeholder)
        );
    }

    echo '</p>';
}

function fyremezzonine_manager_handle_conference_submission() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['fyremezzonine_conference_submission_nonce'])) {
        return '';
    }

    if (!current_user_can('edit_posts')) {
        return '<div class="registration-message registration-error">У вас нет прав для создания конференции.</div>';
    }

    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fyremezzonine_conference_submission_nonce'])), 'fyremezzonine_create_conference')) {
        return '<div class="registration-message registration-error">Не удалось проверить форму. Обновите страницу и попробуйте еще раз.</div>';
    }

    $title = isset($_POST['conference_title']) ? sanitize_text_field(wp_unslash($_POST['conference_title'])) : '';
    if (!$title) {
        return '<div class="registration-message registration-error">Заполните название конференции.</div>';
    }

    $editing_post_id = isset($_POST['conference_id']) ? absint($_POST['conference_id']) : 0;
    if ($editing_post_id && (!get_post($editing_post_id) || !current_user_can('edit_post', $editing_post_id))) {
        return '<div class="registration-message registration-error">У вас нет прав для редактирования этой конференции.</div>';
    }

    $submission_action = isset($_POST['conference_submission_action']) ? sanitize_key(wp_unslash($_POST['conference_submission_action'])) : 'save_draft';
    $current_status = $editing_post_id ? get_post_status($editing_post_id) : '';
    $publish_now = $submission_action === 'publish' && $editing_post_id;
    $post_status = $publish_now || $current_status === 'publish' ? 'publish' : 'draft';

    $post_data = array(
        'post_type' => 'conference',
        'post_status' => $post_status,
        'post_title' => $title,
        'post_excerpt' => isset($_POST['conference_excerpt']) ? sanitize_textarea_field(wp_unslash($_POST['conference_excerpt'])) : '',
        'post_content' => isset($_POST['conference_content']) ? wp_kses_post(wp_unslash($_POST['conference_content'])) : '',
    );

    if ($editing_post_id) {
        $post_data['ID'] = $editing_post_id;
        $post_id = wp_update_post($post_data, true);
    } else {
        $post_id = wp_insert_post($post_data, true);
    }

    if (is_wp_error($post_id)) {
        return '<div class="registration-message registration-error">Конференцию не удалось сохранить. Попробуйте еще раз.</div>';
    }

    $GLOBALS['fyremezzonine_manager_last_saved_conference_id'] = absint($post_id);

    foreach (fyremezzonine_manager_meta_keys() as $key => $field) {
        if ($field['type'] === 'partners') {
            update_post_meta($post_id, $key, fyremezzonine_manager_partner_rows_from_request($key, $post_id));
            continue;
        }
        if ($field['type'] === 'topics') {
            update_post_meta($post_id, $key, fyremezzonine_manager_topic_rows_from_request($key, $post_id));
            continue;
        }
        if ($field['type'] === 'speakers') {
            update_post_meta($post_id, $key, fyremezzonine_manager_speaker_rows_from_request($key, $post_id));
            continue;
        }

        $uploaded_url = in_array($key, fyremezzonine_manager_image_meta_keys(), true) ? fyremezzonine_manager_upload_image_for_field($key, $post_id) : '';
        if ($uploaded_url) {
            $value = $uploaded_url;
        } elseif (isset($_POST[$key])) {
            $value = $field['type'] === 'select'
                ? fyremezzonine_manager_sanitize_select_value($_POST[$key], $field)
                : fyremezzonine_manager_sanitize_submission_value($_POST[$key], $field['type']);
        } else {
            $value = '';
        }
        update_post_meta($post_id, $key, $value);
    }

    $preview_link = fyremezzonine_manager_conference_preview_url($post_id);
    $editor_link = add_query_arg('conference_id', $post_id, fyremezzonine_manager_editor_page_url('edit-conference'));
    $view_link = get_permalink($post_id);
    $is_published = get_post_status($post_id) === 'publish';
    $message = $is_published
        ? 'Конференция опубликована и применена на сайте.'
        : 'Черновик конференции сохранен. Откройте предпросмотр, проверьте страницу и затем нажмите "Опубликовать конференцию".';

    $links = array();
    if ($editor_link) {
        $links[] = '<a href="' . esc_url($editor_link) . '">Продолжить редактирование</a>';
    }
    if ($preview_link) {
        $links[] = '<a href="' . esc_url($preview_link) . '" target="_blank" rel="noopener">Предпросмотр</a>';
    }
    if ($is_published && $view_link) {
        $links[] = '<a href="' . esc_url($view_link) . '">Посмотреть на сайте</a>';
    }

    if ($links) {
        $message .= ' ' . implode(' | ', $links);
    }

    return '<div class="registration-message registration-success">' . wp_kses_post($message) . '</div>';
}

function fyremezzonine_manager_conference_preview_url($post_id) {
    return add_query_arg('conference_id', absint($post_id), fyremezzonine_manager_editor_page_url('conference-preview'));
}

function fyremezzonine_manager_conference_submission_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="registration-message registration-error">Войдите в WordPress, чтобы создать конференцию.</div>';
    }

    if (!current_user_can('edit_posts')) {
        return '<div class="registration-message registration-error">У вашей учетной записи нет прав для создания конференций.</div>';
    }

    $message = fyremezzonine_manager_handle_conference_submission();
    $editing_conference_id = isset($_GET['conference_id']) ? absint($_GET['conference_id']) : 0;
    if (isset($_POST['conference_id'])) {
        $editing_conference_id = absint($_POST['conference_id']);
    }
    if (!empty($GLOBALS['fyremezzonine_manager_last_saved_conference_id'])) {
        $editing_conference_id = absint($GLOBALS['fyremezzonine_manager_last_saved_conference_id']);
    }

    if ($editing_conference_id && (!get_post($editing_conference_id) || !current_user_can('edit_post', $editing_conference_id))) {
        return '<div class="registration-message registration-error">У вас нет прав для редактирования этой конференции.</div>';
    }

    if (!$editing_conference_id && trim((string) wp_parse_url(wp_unslash($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH), '/') === 'editor/edit-conference') {
        return fyremezzonine_manager_render_edit_picker();
    }

    $meta_fields = fyremezzonine_manager_meta_keys();
    $groups = fyremezzonine_manager_submission_field_groups();
    $current_status = $editing_conference_id ? get_post_status($editing_conference_id) : '';
    $status_object = $current_status ? get_post_status_object($current_status) : null;
    $status_label = $status_object ? $status_object->label : $current_status;
    $preview_link = $editing_conference_id ? fyremezzonine_manager_conference_preview_url($editing_conference_id) : '';
    $is_published = $current_status === 'publish';
    $partner_template_conference_id = (!$editing_conference_id && $_SERVER['REQUEST_METHOD'] !== 'POST')
        ? fyremezzonine_manager_latest_partner_template_conference_id()
        : 0;
    $topic_template_conference_id = (!$editing_conference_id && $_SERVER['REQUEST_METHOD'] !== 'POST')
        ? fyremezzonine_manager_latest_topic_template_conference_id()
        : 0;
    $GLOBALS['fyremezzonine_manager_partner_template_conference_id'] = $partner_template_conference_id;
    $GLOBALS['fyremezzonine_manager_topic_template_conference_id'] = $topic_template_conference_id;

    ob_start();
    echo wp_kses_post($message);
    ?>
    <form class="conference-submission-form" method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('fyremezzonine_create_conference', 'fyremezzonine_conference_submission_nonce'); ?>
        <?php if ($editing_conference_id) : ?>
            <input type="hidden" name="conference_id" value="<?php echo esc_attr($editing_conference_id); ?>">
        <?php endif; ?>
        <div class="registration-conference-title">
            <span><?php echo $editing_conference_id ? 'Редактирование конференции' : 'Новая конференция'; ?></span>
            <strong><?php echo $editing_conference_id ? esc_html(get_the_title($editing_conference_id)) : 'Заполните форму, как анкету'; ?></strong>
            <?php if ($editing_conference_id) : ?>
                <div class="conference-submission-state">
                    <span>Статус: <?php echo esc_html($status_label); ?></span>
                    <?php if ($preview_link) : ?>
                        <a class="button button-blue" href="<?php echo esc_url($preview_link); ?>" target="_blank" rel="noopener">Предпросмотр</a>
                    <?php endif; ?>
                </div>
            <?php else : ?>
                <p class="conference-submission-note">Сначала сохраните черновик. После этого появится предпросмотр и кнопка публикации.</p>
                <?php if ($partner_template_conference_id) : ?>
                    <p class="conference-submission-note">Организаторы и партнеры автоматически заполнены по прошлой конференции: <?php echo esc_html(get_the_title($partner_template_conference_id)); ?>. Проверьте список и удалите лишнее перед сохранением.</p>
                <?php endif; ?>
                <?php if ($topic_template_conference_id) : ?>
                    <p class="conference-submission-note">Темы конференции автоматически заполнены по прошлой конференции: <?php echo esc_html(get_the_title($topic_template_conference_id)); ?>. Их можно изменить, удалить или дополнить.</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php foreach ($groups as $group) : ?>
            <fieldset>
                <div class="conference-submission-section-head">
                    <h2><?php echo esc_html($group['title']); ?></h2>
                    <p class="conference-submission-help"><?php echo esc_html($group['description']); ?></p>
                </div>
                <?php foreach ($group['fields'] as $field_name => $field) : ?>
                    <?php
                    if (is_int($field_name)) {
                        $field_name = $field;
                        $field = isset($meta_fields[$field_name]) ? $meta_fields[$field_name] : null;
                    }

                    if (!$field) {
                        continue;
                    }

                    $value = fyremezzonine_manager_submission_value($field_name, $editing_conference_id);
                    fyremezzonine_manager_render_submission_field($field_name, $field, $value);
                    ?>
                <?php endforeach; ?>
            </fieldset>
        <?php endforeach; ?>

        <p class="conference-submission-actions">
            <button class="button button-blue" type="submit" name="conference_submission_action" value="save_draft">
                <?php echo $is_published ? 'Сохранить изменения' : 'Сохранить черновик'; ?>
            </button>
            <?php if ($preview_link) : ?>
                <a class="button button-outline" href="<?php echo esc_url($preview_link); ?>" target="_blank" rel="noopener">Предпросмотр</a>
            <?php endif; ?>
            <?php if ($editing_conference_id) : ?>
                <button class="button button-red" type="submit" name="conference_submission_action" value="publish">
                    <?php echo $is_published ? 'Сохранить опубликованную' : 'Опубликовать конференцию'; ?>
                </button>
            <?php endif; ?>
        </p>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('conference_submission_form', 'fyremezzonine_manager_conference_submission_shortcode');

function fyremezzonine_manager_editor_page_url($page = 'new-conference') {
    return home_url('/editor/' . trim($page, '/') . '/');
}

function fyremezzonine_manager_submission_value($field_name, $conference_id = 0) {
    if (isset($_POST[$field_name])) {
        return wp_unslash($_POST[$field_name]);
    }

    if (!$conference_id) {
        $template_conference_id = !empty($GLOBALS['fyremezzonine_manager_partner_template_conference_id'])
            ? absint($GLOBALS['fyremezzonine_manager_partner_template_conference_id'])
            : 0;

        if ($template_conference_id && in_array($field_name, fyremezzonine_manager_partner_template_meta_keys(), true)) {
            return get_post_meta($template_conference_id, $field_name, true);
        }

        $topic_template_conference_id = !empty($GLOBALS['fyremezzonine_manager_topic_template_conference_id'])
            ? absint($GLOBALS['fyremezzonine_manager_topic_template_conference_id'])
            : 0;

        if ($topic_template_conference_id && in_array($field_name, fyremezzonine_manager_topic_template_meta_keys(), true)) {
            return get_post_meta($topic_template_conference_id, $field_name, true);
        }

        return '';
    }

    $post = get_post($conference_id);
    if (!$post) {
        return '';
    }

    if ($field_name === 'conference_title') {
        return $post->post_title;
    }

    if ($field_name === 'conference_excerpt') {
        return $post->post_excerpt;
    }

    if ($field_name === 'conference_content') {
        return $post->post_content;
    }

    return get_post_meta($conference_id, $field_name, true);
}

function fyremezzonine_manager_render_edit_picker() {
    $conferences = fyremezzonine_manager_get_conference_options();

    ob_start();
    ?>
    <div class="conference-editor-picker">
        <p>Выберите конференцию, которую нужно изменить. После выбора откроется такая же анкета, но уже с заполненными данными.</p>
        <?php if ($conferences) : ?>
            <div class="conference-editor-picker-list">
                <?php foreach ($conferences as $conference) : ?>
                    <?php
                    $status_object = get_post_status_object(get_post_status($conference));
                    $status_label = $status_object ? $status_object->label : get_post_status($conference);
                    ?>
                    <a class="conference-editor-picker-item" href="<?php echo esc_url(add_query_arg('conference_id', $conference->ID, fyremezzonine_manager_editor_page_url('edit-conference'))); ?>">
                        <strong><?php echo esc_html(get_the_title($conference)); ?></strong>
                        <span><?php echo esc_html($status_label); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else : ?>
            <div class="registration-message registration-error">Пока нет конференций для редактирования.</div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function fyremezzonine_manager_format_date($date) {
    if (!$date) {
        return '';
    }

    return date_i18n('d.m.Y', strtotime($date));
}

function fyremezzonine_manager_registration_is_closed($conference_id) {
    $deadline = get_post_meta($conference_id, '_conference_registration_deadline', true);

    return $deadline && $deadline < current_time('Y-m-d');
}

function fyremezzonine_manager_closed_registration_message($conference_id) {
    $deadline = get_post_meta($conference_id, '_conference_registration_deadline', true);
    $deadline_text = fyremezzonine_manager_format_date($deadline);

    $text = $deadline_text ? 'Дедлайн регистрации: ' . $deadline_text . '.' : 'Прием заявок на эту конференцию завершен.';

    return '<div class="registration-message registration-closed"><strong>Регистрация закрыта</strong><br>' . esc_html($text) . '</div>';
}

function fyremezzonine_manager_privacy_policy_url() {
    $policy_url = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';

    return $policy_url ?: home_url('/privacy-policy/');
}

function fyremezzonine_manager_registration_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'conference_id' => 0,
        ),
        $atts,
        'conference_registration_form'
    );

    $conference_id = absint($atts['conference_id']);
    if (!$conference_id && isset($_GET['conference_id'])) {
        $conference_id = absint($_GET['conference_id']);
    }
    if (!$conference_id && is_singular('conference')) {
        $conference_id = get_the_ID();
    }
    if (!$conference_id) {
        $conference_id = fyremezzonine_manager_latest_conference_id();
    }

    $message = '';

    if (!$conference_id) {
        return '<div class="registration-message registration-error">Сейчас нет опубликованных конференций для регистрации.</div>';
    }

    if (fyremezzonine_manager_registration_is_closed($conference_id)) {
        return fyremezzonine_manager_closed_registration_message($conference_id);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fyremezzonine_registration_nonce'])) {
        $message = fyremezzonine_manager_handle_registration($conference_id);
    }

    ob_start();
    if ($message) {
        echo wp_kses_post($message);
    }
    ?>
    <form class="conference-registration-form" method="post">
        <?php wp_nonce_field('fyremezzonine_register_' . $conference_id, 'fyremezzonine_registration_nonce'); ?>
        <input type="hidden" name="conference_id" value="<?php echo esc_attr($conference_id); ?>">
        <div class="registration-conference-title">
            <span>Регистрация на конференцию</span>
            <strong><?php echo esc_html(get_the_title($conference_id)); ?></strong>
        </div>
        <div class="registration-name-grid">
            <p>
                <label>Фамилия<br>
                    <input type="text" name="last_name" required>
                </label>
            </p>
            <p>
                <label>Имя<br>
                    <input type="text" name="first_name" required>
                </label>
            </p>
            <p>
                <label>Отчество<br>
                    <input type="text" name="middle_name">
                </label>
            </p>
        </div>
        <p>
            <label>Email<br>
                <input type="email" name="email" required>
            </label>
        </p>
        <p>
            <label>Должность<br>
                <input type="text" name="job_position" placeholder="Например: генеральный директор">
            </label>
        </p>
        <p>
            <label>Телефон<br>
                <input type="tel" name="phone">
            </label>
        </p>
        <p>
            <label>Организация<br>
                <input type="text" name="organization">
            </label>
        </p>
        <fieldset class="registration-participant-types">
            <legend>Тип участника</legend>
            <div class="registration-checkbox-grid">
                <?php foreach (fyremezzonine_manager_participant_type_options() as $type_key => $type_label) : ?>
                    <label>
                        <input type="checkbox" name="participant_types[]" value="<?php echo esc_attr($type_key); ?>">
                        <span><?php echo esc_html($type_label); ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>
        <p>
            <label>Комментарий<br>
                <textarea name="comment" rows="4"></textarea>
            </label>
        </p>
        <p class="registration-consent">
            <label>
                <input type="checkbox" name="privacy_consent" value="1" required>
                <span>Я согласен(а) с <a href="<?php echo esc_url(fyremezzonine_manager_privacy_policy_url()); ?>" target="_blank" rel="noopener">политикой обработки персональных данных</a>.</span>
            </label>
        </p>
        <p><button class="button button-red" type="submit">Отправить заявку</button></p>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('conference_registration_form', 'fyremezzonine_manager_registration_shortcode');

function fyremezzonine_manager_latest_conference_id() {
    $today = current_time('Y-m-d');
    $query = new WP_Query(
        array(
            'post_type' => 'conference',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'meta_value',
            'meta_key' => '_conference_start_date',
            'order' => 'ASC',
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => '_conference_start_date',
                    'value' => $today,
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
            ),
        )
    );

    if ($query->posts) {
        return absint($query->posts[0]);
    }

    $fallback = new WP_Query(
        array(
            'post_type' => 'conference',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'meta_value',
            'meta_key' => '_conference_start_date',
            'order' => 'DESC',
            'fields' => 'ids',
        )
    );

    return $fallback->posts ? absint($fallback->posts[0]) : 0;
}

function fyremezzonine_manager_handle_registration($fallback_conference_id) {
    global $wpdb;

    $conference_id = isset($_POST['conference_id']) ? absint($_POST['conference_id']) : $fallback_conference_id;

    if (!$conference_id || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fyremezzonine_registration_nonce'])), 'fyremezzonine_register_' . $conference_id)) {
        return '<div class="registration-message registration-error">Не удалось проверить форму. Обновите страницу и попробуйте еще раз.</div>';
    }

    if (fyremezzonine_manager_registration_is_closed($conference_id)) {
        return fyremezzonine_manager_closed_registration_message($conference_id);
    }

    $last_name = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';
    $first_name = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
    $middle_name = isset($_POST['middle_name']) ? sanitize_text_field(wp_unslash($_POST['middle_name'])) : '';
    $full_name = trim(preg_replace('/\s+/', ' ', $last_name . ' ' . $first_name . ' ' . $middle_name));
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $job_position = isset($_POST['job_position']) ? sanitize_text_field(wp_unslash($_POST['job_position'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $organization = isset($_POST['organization']) ? sanitize_text_field(wp_unslash($_POST['organization'])) : '';
    $participant_types = fyremezzonine_manager_sanitize_participant_types(isset($_POST['participant_types']) ? wp_unslash($_POST['participant_types']) : array());
    $comment = isset($_POST['comment']) ? sanitize_textarea_field(wp_unslash($_POST['comment'])) : '';
    $privacy_consent = isset($_POST['privacy_consent']) && $_POST['privacy_consent'] === '1';

    if (!$last_name || !$first_name || !$email || !is_email($email)) {
        return '<div class="registration-message registration-error">Заполните фамилию, имя и корректный email.</div>';
    }

    if (!$participant_types) {
        return '<div class="registration-message registration-error">Выберите хотя бы один тип участника.</div>';
    }

    if (!$privacy_consent) {
        return '<div class="registration-message registration-error">Подтвердите согласие с политикой обработки персональных данных.</div>';
    }

    $ip_address = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    $wpdb->insert(
        fyremezzonine_manager_table_name(),
        array(
            'conference_id' => $conference_id,
            'full_name' => $full_name,
            'last_name' => $last_name,
            'first_name' => $first_name,
            'middle_name' => $middle_name,
            'job_position' => $job_position,
            'email' => $email,
            'phone' => $phone,
            'organization' => $organization,
            'participant_types' => implode(',', $participant_types),
            'comment' => $comment,
            'privacy_consent' => 1,
            'status' => 'new',
            'ip_address' => $ip_address,
            'created_at' => current_time('mysql'),
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s')
    );

    return fyremezzonine_manager_registration_success_message($conference_id);
}

function fyremezzonine_manager_registration_success_message($conference_id) {
    $chat_url = get_post_meta($conference_id, '_conference_chat_1_url', true);

    $message = '<div class="registration-message registration-success">';
    $message .= '<strong>Спасибо! Заявка отправлена.</strong>';

    if ($chat_url) {
        $message .= '<div class="registration-chat-links">';
        $message .= '<p>Теперь можно присоединиться к чату конференции.</p>';
        $message .= '<div class="registration-chat-actions">';
        $message .= '<a class="button button-blue" href="' . esc_url($chat_url) . '">Чат конференции</a>';
        $message .= '</div>';
        $message .= '</div>';
    }

    $message .= '</div>';

    return $message;
}

function fyremezzonine_manager_partner_request_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'conference_id' => 0,
        ),
        $atts,
        'conference_partner_request_form'
    );

    $conference_id = absint($atts['conference_id']) ?: fyremezzonine_manager_latest_conference_id();
    $message = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fyremezzonine_partner_request_nonce'])) {
        $message = fyremezzonine_manager_handle_partner_request($conference_id);
    }

    ob_start();
    if ($message) {
        echo wp_kses_post($message);
    }
    ?>
    <form class="conference-registration-form conference-partner-request-form" method="post">
        <?php wp_nonce_field('fyremezzonine_partner_request_' . $conference_id, 'fyremezzonine_partner_request_nonce'); ?>
        <input type="hidden" name="conference_id" value="<?php echo esc_attr($conference_id); ?>">
        <div class="registration-conference-title">
            <span>Заявка на партнерство</span>
            <strong><?php echo $conference_id ? esc_html(get_the_title($conference_id)) : 'Конференция ВНИИПО'; ?></strong>
        </div>
        <p>
            <label>Название компании<br>
                <input type="text" name="company_name" required placeholder="Например: ООО &quot;Пожарные технологии&quot;">
            </label>
        </p>
        <p>
            <label>Сайт компании<br>
                <input type="url" name="company_site" placeholder="https://example.ru/">
            </label>
        </p>
        <p>
            <label>Город<br>
                <input type="text" name="company_city" placeholder="Например: Оренбург">
            </label>
        </p>
        <p>
            <label>Степень партнерства<br>
                <select name="partnership_level" required>
                    <?php foreach (fyremezzonine_manager_partnership_level_options() as $level_key => $level_label) : ?>
                        <option value="<?php echo esc_attr($level_key); ?>" <?php selected($level_key, 'partner'); ?>>
                            <?php echo esc_html($level_label); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
        </p>
        <p>
            <label>Контактное лицо<br>
                <input type="text" name="contact_name" required placeholder="Фамилия Имя Отчество">
            </label>
        </p>
        <p>
            <label>Должность<br>
                <input type="text" name="contact_position" placeholder="Например: директор по развитию">
            </label>
        </p>
        <p>
            <label>Email<br>
                <input type="email" name="email" required placeholder="mail@example.ru">
            </label>
        </p>
        <p>
            <label>Телефон<br>
                <input type="tel" name="phone" placeholder="+7">
            </label>
        </p>
        <p>
            <label>Комментарий<br>
                <textarea name="comment" rows="5" placeholder="Опишите формат участия, вопросы или пожелания"></textarea>
            </label>
        </p>
        <p><button class="button button-red" type="submit">Отправить заявку</button></p>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('conference_partner_request_form', 'fyremezzonine_manager_partner_request_shortcode');

function fyremezzonine_manager_handle_partner_request($fallback_conference_id) {
    global $wpdb;

    $conference_id = isset($_POST['conference_id']) ? absint($_POST['conference_id']) : $fallback_conference_id;

    if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fyremezzonine_partner_request_nonce'])), 'fyremezzonine_partner_request_' . $conference_id)) {
        return '<div class="registration-message registration-error">Не удалось проверить форму. Обновите страницу и попробуйте еще раз.</div>';
    }

    $company_name = isset($_POST['company_name']) ? sanitize_text_field(wp_unslash($_POST['company_name'])) : '';
    $company_site = isset($_POST['company_site']) ? esc_url_raw(wp_unslash($_POST['company_site'])) : '';
    $company_city = isset($_POST['company_city']) ? sanitize_text_field(wp_unslash($_POST['company_city'])) : '';
    $partnership_level = isset($_POST['partnership_level']) ? sanitize_key(wp_unslash($_POST['partnership_level'])) : 'partner';
    $contact_name = isset($_POST['contact_name']) ? sanitize_text_field(wp_unslash($_POST['contact_name'])) : '';
    $contact_position = isset($_POST['contact_position']) ? sanitize_text_field(wp_unslash($_POST['contact_position'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $comment = isset($_POST['comment']) ? sanitize_textarea_field(wp_unslash($_POST['comment'])) : '';

    if (!$company_name || !$contact_name || !$email || !is_email($email)) {
        return '<div class="registration-message registration-error">Заполните название компании, контактное лицо и корректный email.</div>';
    }

    if (!array_key_exists($partnership_level, fyremezzonine_manager_partnership_level_options())) {
        $partnership_level = 'partner';
    }

    $ip_address = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';

    $wpdb->insert(
        fyremezzonine_manager_partner_requests_table_name(),
        array(
            'conference_id' => $conference_id,
            'company_name' => $company_name,
            'company_site' => $company_site,
            'company_city' => $company_city,
            'partnership_level' => $partnership_level,
            'contact_name' => $contact_name,
            'contact_position' => $contact_position,
            'email' => $email,
            'phone' => $phone,
            'comment' => $comment,
            'status' => 'new',
            'ip_address' => $ip_address,
            'created_at' => current_time('mysql'),
        ),
        array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
    );

    return '<div class="registration-message registration-success">Спасибо! Заявка на партнерство отправлена. Представители ВНИИПО свяжутся с вами.</div>';
}

function fyremezzonine_manager_render_simple_create_page() {
    ?>
    <div class="wrap fyremezzonine-simple-create">
        <h1>Создать конференцию через форму</h1>
        <p>Эта страница работает как анкета: сохраните черновик, проверьте предпросмотр и только затем опубликуйте конференцию.</p>
        <style>
            .fyremezzonine-simple-create .conference-submission-form {
                display: grid;
                gap: 18px;
                max-width: 860px;
                margin-top: 20px;
                padding: 0;
                border: 0;
                background: transparent;
            }
            .fyremezzonine-simple-create fieldset {
                display: grid;
                grid-template-columns: 1fr;
                gap: 16px;
                min-width: 0;
                margin: 0;
                padding: 0 20px 20px;
                border: 1px solid #dcdcde;
                border-radius: 8px;
                background: #fff;
                overflow: hidden;
            }
            .fyremezzonine-simple-create .conference-submission-section-head {
                display: grid;
                grid-column: 1 / -1;
                gap: 6px;
                min-width: 0;
                margin: 0 -20px 4px;
                padding: 18px 20px 14px;
                border-bottom: 1px solid #dcdcde;
                background: #f6f7f7;
            }
            .fyremezzonine-simple-create .conference-submission-section-head h2 {
                margin: 0;
                font-size: 20px;
                font-weight: 700;
                line-height: 1.2;
                overflow-wrap: anywhere;
            }
            .fyremezzonine-simple-create .registration-conference-title {
                display: grid;
                gap: 6px;
                padding: 20px;
                border: 1px solid #dcdcde;
                border-left: 6px solid #525afc;
                border-radius: 8px;
                background: #fff;
            }
            .fyremezzonine-simple-create .registration-conference-title span {
                color: #646970;
                font-weight: 700;
                text-transform: uppercase;
            }
            .fyremezzonine-simple-create .registration-conference-title strong {
                font-size: 22px;
            }
            .fyremezzonine-simple-create .conference-submission-state,
            .fyremezzonine-simple-create .conference-submission-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                align-items: center;
            }
            .fyremezzonine-simple-create .conference-submission-actions {
                justify-content: flex-end;
            }
            .fyremezzonine-simple-create .conference-submission-state span {
                display: inline-flex;
                align-items: center;
                min-height: 36px;
                padding: 7px 10px;
                border: 1px solid #dcdcde;
                border-radius: 6px;
                color: #646970;
                background: #f6f7f7;
                font-weight: 700;
            }
            .fyremezzonine-simple-create .conference-submission-help {
                margin: 0;
                color: #646970;
                overflow-wrap: anywhere;
            }
            .fyremezzonine-simple-create .conference-submission-field {
                display: grid;
                gap: 7px;
                min-width: 0;
                margin: 0;
            }
            .fyremezzonine-simple-create .conference-submission-field:has(textarea),
            .fyremezzonine-simple-create .conference-submission-field:has(input[type="file"]),
            .fyremezzonine-simple-create .conference-partner-repeater {
                grid-column: 1 / -1;
            }
            .fyremezzonine-simple-create .conference-submission-field label {
                font-weight: 700;
                min-width: 0;
                overflow-wrap: anywhere;
            }
            .fyremezzonine-simple-create input,
            .fyremezzonine-simple-create textarea,
            .fyremezzonine-simple-create select {
                width: 100%;
                min-width: 0;
                max-width: 100%;
            }
        </style>
        <?php echo do_shortcode('[conference_submission_form]'); ?>
    </div>
    <?php
}

function fyremezzonine_manager_admin_menu() {
    add_submenu_page(
        'edit.php?post_type=conference',
        'Создать через форму',
        'Создать через форму',
        'edit_posts',
        'conference-create-simple',
        'fyremezzonine_manager_render_simple_create_page'
    );

    add_submenu_page(
        'edit.php?post_type=conference',
        'Заявки',
        'Заявки',
        'edit_posts',
        'conference-registrations',
        'fyremezzonine_manager_render_registrations_page'
    );

    add_submenu_page(
        'edit.php?post_type=conference',
        'Заявки на партнерство',
        'Заявки на партнерство',
        'edit_posts',
        'conference-partner-requests',
        'fyremezzonine_manager_render_partner_requests_page'
    );

    add_submenu_page(
        'edit.php?post_type=conference',
        'Как редактировать сайт',
        'Как редактировать сайт',
        'edit_posts',
        'conference-editing-guide',
        'fyremezzonine_manager_render_guide_page'
    );
}
add_action('admin_menu', 'fyremezzonine_manager_admin_menu');

function fyremezzonine_manager_is_frontend_editor_user($user = null) {
    if ($user instanceof WP_User) {
        return user_can($user, 'edit_posts') && !user_can($user, 'manage_options');
    }

    return is_user_logged_in() && current_user_can('edit_posts') && !current_user_can('manage_options');
}

function fyremezzonine_manager_redirect_editor_after_login($redirect_to, $requested_redirect_to, $user) {
    if (fyremezzonine_manager_is_frontend_editor_user($user)) {
        return home_url('/');
    }

    return $redirect_to;
}
add_filter('login_redirect', 'fyremezzonine_manager_redirect_editor_after_login', 10, 3);

function fyremezzonine_manager_keep_editor_on_frontend() {
    if (wp_doing_ajax() || !fyremezzonine_manager_is_frontend_editor_user()) {
        return;
    }

    wp_safe_redirect(home_url('/'));
    exit;
}
add_action('admin_init', 'fyremezzonine_manager_keep_editor_on_frontend');

function fyremezzonine_manager_hide_admin_bar_for_editor($show) {
    if (fyremezzonine_manager_is_frontend_editor_user()) {
        return false;
    }

    return $show;
}
add_filter('show_admin_bar', 'fyremezzonine_manager_hide_admin_bar_for_editor');

function fyremezzonine_manager_get_conference_options() {
    return get_posts(
        array(
            'post_type' => 'conference',
            'post_status' => array('publish', 'draft', 'future', 'private'),
            'numberposts' => -1,
            'orderby' => 'meta_value',
            'meta_key' => '_conference_start_date',
            'order' => 'DESC',
        )
    );
}

function fyremezzonine_manager_registrations_query($conference_id = 0, $limit = 0) {
    global $wpdb;

    $table = fyremezzonine_manager_table_name();
    $sql = "SELECT r.*, p.post_title AS conference_title FROM {$table} r LEFT JOIN {$wpdb->posts} p ON p.ID = r.conference_id";
    $params = array();

    if ($conference_id) {
        $sql .= ' WHERE r.conference_id = %d';
        $params[] = $conference_id;
    }

    $sql .= ' ORDER BY r.created_at DESC';

    if ($limit) {
        $sql .= ' LIMIT %d';
        $params[] = $limit;
    }

    if ($params) {
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }

    return $wpdb->get_results($sql);
}

function fyremezzonine_manager_export_registrations() {
    if (!current_user_can('edit_posts')) {
        wp_die('Недостаточно прав.');
    }

    check_admin_referer('fyremezzonine_export_registrations');

    $conference_id = isset($_GET['conference_id']) ? absint($_GET['conference_id']) : 0;
    $items = fyremezzonine_manager_registrations_query($conference_id);
    $conference_slug = $conference_id ? sanitize_title(get_the_title($conference_id)) : 'all';
    $filename = 'conference-registrations-' . $conference_slug . '-' . gmdate('Y-m-d') . '.xls';

    nocache_headers();
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    echo "\xEF\xBB\xBF";
    echo '<!doctype html><html><head><meta charset="UTF-8"></head><body>';
    echo '<table border="1">';
    echo '<thead><tr>';
    foreach (array('ID', 'Дата', 'Конференция', 'Фамилия', 'Имя', 'Отчество', 'Должность', 'Email', 'Телефон', 'Организация', 'Тип участника', 'Комментарий', 'Согласие', 'Статус', 'IP') as $heading) {
        echo '<th>' . esc_html($heading) . '</th>';
    }
    echo '</tr></thead><tbody>';

    foreach ($items as $item) {
        list($last_name, $first_name, $middle_name) = fyremezzonine_manager_registration_name_parts($item);
        echo '<tr>';
        foreach (
            array(
                $item->id,
                $item->created_at,
                $item->conference_title,
                $last_name,
                $first_name,
                $middle_name,
                $item->job_position,
                $item->email,
                $item->phone,
                $item->organization,
                fyremezzonine_manager_participant_types_label($item->participant_types ?? ''),
                $item->comment,
                $item->privacy_consent ? 'Да' : 'Нет',
                $item->status,
                $item->ip_address,
            ) as $cell
        ) {
            echo '<td>' . esc_html((string) $cell) . '</td>';
        }
        echo '</tr>';
    }

    echo '</tbody></table></body></html>';
    exit;
}
add_action('admin_post_fyremezzonine_export_registrations', 'fyremezzonine_manager_export_registrations');

function fyremezzonine_manager_registration_name_parts($item) {
    $last_name = isset($item->last_name) ? trim((string) $item->last_name) : '';
    $first_name = isset($item->first_name) ? trim((string) $item->first_name) : '';
    $middle_name = isset($item->middle_name) ? trim((string) $item->middle_name) : '';

    if (!$last_name && !$first_name && !$middle_name && !empty($item->full_name)) {
        $parts = preg_split('/\s+/', trim((string) $item->full_name), 3);
        $last_name = $parts[0] ?? '';
        $first_name = $parts[1] ?? '';
        $middle_name = $parts[2] ?? '';
    }

    return array($last_name, $first_name, $middle_name);
}

function fyremezzonine_manager_status_badge($status) {
    $status = sanitize_key($status ?: 'new');
    $labels = array(
        'new' => 'Новая',
        'confirmed' => 'Подтверждена',
        'approved' => 'Одобрена',
        'rejected' => 'Отклонена',
        'archived' => 'Архив',
    );
    $label = $labels[$status] ?? $status;

    return sprintf(
        '<span class="request-status request-status-%1$s">%2$s</span>',
        esc_attr($status),
        esc_html($label)
    );
}

function fyremezzonine_manager_print_controls($label = 'Распечатать список') {
    static $printed_assets = false;

    ob_start();

    if (!$printed_assets) :
        $printed_assets = true;
        ?>
        <style>
            .conference-print-title {
                display: none;
            }

            @media print {
                body.conference-print-mode * {
                    visibility: hidden !important;
                }

                body.conference-print-mode .conference-print-area,
                body.conference-print-mode .conference-print-area * {
                    visibility: visible !important;
                }

                body.conference-print-mode .conference-print-area {
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    width: 100% !important;
                    padding: 0 !important;
                    background: #fff !important;
                    color: #000 !important;
                    font-family: Calibri, Arial, sans-serif !important;
                }

                body.conference-print-mode .conference-print-actions,
                body.conference-print-mode .conference-editor-filter,
                body.conference-print-mode .conference-admin-filter {
                    display: none !important;
                }

                body.conference-print-mode .conference-print-title {
                    display: block !important;
                    margin: 0 0 10px !important;
                    color: #000 !important;
                    font-family: Calibri, Arial, sans-serif !important;
                    font-size: 16px !important;
                    font-weight: 700 !important;
                    line-height: 1.2 !important;
                }

                body.conference-print-mode .conference-registrations-scroll {
                    overflow: visible !important;
                    margin: 0 !important;
                }

                body.conference-print-mode table {
                    width: 100% !important;
                    min-width: 0 !important;
                    border-collapse: collapse !important;
                    box-shadow: none !important;
                    table-layout: fixed !important;
                    color: #000 !important;
                    font-family: Calibri, Arial, sans-serif !important;
                    font-size: 9pt !important;
                    line-height: 1.15 !important;
                }

                body.conference-print-mode thead {
                    display: table-header-group !important;
                }

                body.conference-print-mode tfoot {
                    display: table-footer-group !important;
                }

                body.conference-print-mode tr {
                    break-inside: avoid !important;
                    page-break-inside: avoid !important;
                }

                body.conference-print-mode th,
                body.conference-print-mode td {
                    padding: 4px 5px !important;
                    border: 1px solid #9e9e9e !important;
                    color: #000 !important;
                    background: #fff !important;
                    text-align: left !important;
                    vertical-align: top !important;
                    white-space: normal !important;
                    overflow-wrap: anywhere !important;
                }

                body.conference-print-mode th {
                    background: #d9eaf7 !important;
                    font-weight: 700 !important;
                    text-transform: none !important;
                }

                body.conference-print-mode tbody tr:nth-child(even) td {
                    background: #f8fbfd !important;
                }

                body.conference-print-mode a {
                    color: #000 !important;
                    text-decoration: none !important;
                }

                body.conference-print-mode .request-status {
                    display: inline !important;
                    min-height: 0 !important;
                    padding: 0 !important;
                    border-radius: 0 !important;
                    background: transparent !important;
                    color: #000 !important;
                    font: inherit !important;
                    white-space: normal !important;
                }

                @page {
                    size: landscape;
                    margin: 12mm;
                }
            }
        </style>
        <script>
            (function () {
                if (window.fyremezzoninePrintList) {
                    return;
                }

                window.fyremezzoninePrintList = function () {
                    document.body.classList.add('conference-print-mode');
                    window.print();
                };

                window.addEventListener('afterprint', function () {
                    document.body.classList.remove('conference-print-mode');
                });
            }());
        </script>
        <?php
    endif;
    ?>
    <div class="conference-print-actions">
        <button type="button" class="button button-outline conference-print-button" onclick="window.fyremezzoninePrintList()"><?php echo esc_html($label); ?></button>
    </div>
    <?php
    return ob_get_clean();
}

function fyremezzonine_manager_default_conference_filter() {
    if (function_exists('fyremezzonine_next_conference_id')) {
        return absint(fyremezzonine_next_conference_id());
    }

    $today = current_time('Y-m-d');
    $query = new WP_Query(
        array(
            'post_type' => 'conference',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_key' => '_conference_start_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'fields' => 'ids',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_conference_end_date',
                    'value' => $today,
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
                array(
                    'relation' => 'AND',
                    array(
                        'key' => '_conference_end_date',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => '_conference_start_date',
                        'value' => $today,
                        'compare' => '>=',
                        'type' => 'DATE',
                    ),
                ),
                array(
                    'relation' => 'AND',
                    array(
                        'key' => '_conference_end_date',
                        'value' => '',
                        'compare' => '=',
                    ),
                    array(
                        'key' => '_conference_start_date',
                        'value' => $today,
                        'compare' => '>=',
                        'type' => 'DATE',
                    ),
                ),
            ),
        )
    );

    if (!empty($query->posts[0])) {
        return absint($query->posts[0]);
    }

    $fallback = new WP_Query(
        array(
            'post_type' => 'conference',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_key' => '_conference_start_date',
            'orderby' => 'meta_value',
            'order' => 'DESC',
            'fields' => 'ids',
        )
    );

    return !empty($fallback->posts[0]) ? absint($fallback->posts[0]) : 0;
}

function fyremezzonine_manager_registrations_interface($admin_mode = false) {
    $conference_id = isset($_GET['conference_id']) ? absint($_GET['conference_id']) : fyremezzonine_manager_default_conference_filter();
    $items = fyremezzonine_manager_registrations_query($conference_id, 200);
    $conferences = fyremezzonine_manager_get_conference_options();
    $export_url = wp_nonce_url(
        add_query_arg(
            array(
                'action' => 'fyremezzonine_export_registrations',
                'conference_id' => $conference_id,
            ),
            admin_url('admin-post.php')
        ),
        'fyremezzonine_export_registrations'
    );
    $form_action = $admin_mode ? admin_url('edit.php') : fyremezzonine_manager_editor_page_url('registrations');
    $table_class = ($admin_mode ? 'widefat fixed striped' : 'conference-registrations-table') . ' conference-registrations-table-participants';
    ob_start();
    ?>
    <p>Регистрации не удаляются после завершения конференции: старые заявки остаются в архиве и доступны по фильтру.</p>

    <form class="<?php echo $admin_mode ? 'conference-admin-filter' : 'conference-editor-filter'; ?>" method="get" action="<?php echo esc_url($form_action); ?>">
        <?php if ($admin_mode) : ?>
            <input type="hidden" name="post_type" value="conference">
            <input type="hidden" name="page" value="conference-registrations">
        <?php endif; ?>
        <p>
            <label for="conference_id"><strong>Конференция</strong></label>
            <select id="conference_id" name="conference_id" onchange="this.form.submit()">
                <option value="0">Все конференции</option>
                <?php foreach ($conferences as $conference) : ?>
                    <option value="<?php echo esc_attr($conference->ID); ?>" <?php selected($conference_id, $conference->ID); ?>>
                        <?php echo esc_html(get_the_title($conference)); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <a class="<?php echo $admin_mode ? 'button button-primary' : 'button button-red'; ?>" href="<?php echo esc_url($export_url); ?>">Выгрузить Excel</a>
    </form>

    <?php echo fyremezzonine_manager_print_controls('Распечатать заявки на участие'); ?>

    <div class="conference-print-area">
        <h2 class="conference-print-title">Список заявок на участие</h2>
        <div class="conference-registrations-scroll">
        <table class="<?php echo esc_attr($table_class); ?>">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Конференция</th>
                    <th>Фамилия</th>
                    <th>Имя</th>
                    <th>Отчество</th>
                    <th>Должность</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Организация</th>
                    <th>Тип участника</th>
                    <th>Комментарий</th>
                    <th>Согласие</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($items) : ?>
                    <?php foreach ($items as $item) : ?>
                        <?php list($last_name, $first_name, $middle_name) = fyremezzonine_manager_registration_name_parts($item); ?>
                        <tr>
                            <td><?php echo esc_html($item->created_at); ?></td>
                            <td><?php echo esc_html($item->conference_title); ?></td>
                            <td><?php echo esc_html($last_name); ?></td>
                            <td><?php echo esc_html($first_name); ?></td>
                            <td><?php echo esc_html($middle_name); ?></td>
                            <td><?php echo esc_html($item->job_position); ?></td>
                            <td><a href="mailto:<?php echo esc_attr($item->email); ?>"><?php echo esc_html($item->email); ?></a></td>
                            <td><?php echo esc_html($item->phone); ?></td>
                            <td><?php echo esc_html($item->organization); ?></td>
                            <td><?php echo esc_html(fyremezzonine_manager_participant_types_label($item->participant_types ?? '')); ?></td>
                            <td><?php echo esc_html($item->comment); ?></td>
                            <td><?php echo $item->privacy_consent ? 'Да' : 'Нет'; ?></td>
                            <td><?php echo fyremezzonine_manager_status_badge($item->status); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="13">Пока заявок нет.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function fyremezzonine_manager_registrations_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="registration-message registration-error">Войдите в WordPress, чтобы посмотреть заявки.</div>';
    }

    if (!current_user_can('edit_posts')) {
        return '<div class="registration-message registration-error">У вашей учетной записи нет прав для просмотра заявок.</div>';
    }

    return fyremezzonine_manager_registrations_interface(false);
}
add_shortcode('conference_registrations_archive', 'fyremezzonine_manager_registrations_shortcode');

function fyremezzonine_manager_partner_requests_query($conference_id = 0, $limit = 200) {
    global $wpdb;

    $table = fyremezzonine_manager_partner_requests_table_name();
    $posts_table = $wpdb->posts;
    $sql = "SELECT p.*, COALESCE(c.post_title, '') AS conference_title
            FROM {$table} p
            LEFT JOIN {$posts_table} c ON c.ID = p.conference_id";
    $params = array();

    if ($conference_id) {
        $sql .= ' WHERE p.conference_id = %d';
        $params[] = $conference_id;
    }

    $sql .= ' ORDER BY p.created_at DESC';

    if ($limit) {
        $sql .= ' LIMIT %d';
        $params[] = $limit;
    }

    if ($params) {
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }

    return $wpdb->get_results($sql);
}

function fyremezzonine_manager_partner_requests_interface($admin_mode = false) {
    $conference_id = isset($_GET['conference_id']) ? absint($_GET['conference_id']) : fyremezzonine_manager_default_conference_filter();
    $items = fyremezzonine_manager_partner_requests_query($conference_id, 200);
    $conferences = fyremezzonine_manager_get_conference_options();
    $form_action = $admin_mode ? admin_url('edit.php') : fyremezzonine_manager_editor_page_url('partner-requests');
    $table_class = ($admin_mode ? 'widefat fixed striped' : 'conference-registrations-table') . ' conference-registrations-table-partners';

    ob_start();
    ?>
    <p>Здесь хранятся заявки от компаний, которые хотят стать партнерами, соорганизаторами или представителями СМИ. ВНИИПО связывается с заявителями по указанным контактам.</p>
    <form class="<?php echo $admin_mode ? 'conference-admin-filter' : 'conference-editor-filter'; ?>" method="get" action="<?php echo esc_url($form_action); ?>">
        <?php if ($admin_mode) : ?>
            <input type="hidden" name="post_type" value="conference">
            <input type="hidden" name="page" value="conference-partner-requests">
        <?php endif; ?>
        <p>
            <label for="partner_conference_id"><strong>Конференция</strong></label>
            <select id="partner_conference_id" name="conference_id" onchange="this.form.submit()">
                <option value="0">Все конференции</option>
                <?php foreach ($conferences as $conference) : ?>
                    <option value="<?php echo esc_attr($conference->ID); ?>" <?php selected($conference_id, $conference->ID); ?>>
                        <?php echo esc_html(get_the_title($conference)); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
    </form>
    <?php echo fyremezzonine_manager_print_controls('Распечатать заявки на партнерство'); ?>

    <div class="conference-print-area">
        <h2 class="conference-print-title">Список заявок на партнерство</h2>
        <div class="conference-registrations-scroll">
        <table class="<?php echo esc_attr($table_class); ?>">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Конференция</th>
                    <th>Компания</th>
                    <th>Степень партнерства</th>
                    <th>Сайт</th>
                    <th>Город</th>
                    <th>Контакт</th>
                    <th>Должность</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Комментарий</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($items) : ?>
                    <?php foreach ($items as $item) : ?>
                        <tr>
                            <td><?php echo esc_html($item->created_at); ?></td>
                            <td><?php echo esc_html($item->conference_title ?: 'Не указана'); ?></td>
                            <td><?php echo esc_html($item->company_name); ?></td>
                            <td><?php echo esc_html(fyremezzonine_manager_partnership_level_label($item->partnership_level ?? 'partner')); ?></td>
                            <td>
                                <?php if (!empty($item->company_site)) : ?>
                                    <a href="<?php echo esc_url($item->company_site); ?>" target="_blank" rel="noopener">Сайт</a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($item->company_city); ?></td>
                            <td><?php echo esc_html($item->contact_name); ?></td>
                            <td><?php echo esc_html($item->contact_position); ?></td>
                            <td><a href="mailto:<?php echo esc_attr($item->email); ?>"><?php echo esc_html($item->email); ?></a></td>
                            <td><?php echo esc_html($item->phone); ?></td>
                            <td><?php echo esc_html($item->comment); ?></td>
                            <td><?php echo fyremezzonine_manager_status_badge($item->status); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="12">Пока заявок на партнерство нет.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function fyremezzonine_manager_partner_requests_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="registration-message registration-error">Войдите в WordPress, чтобы посмотреть заявки.</div>';
    }

    if (!current_user_can('edit_posts')) {
        return '<div class="registration-message registration-error">У вашей учетной записи нет прав для просмотра заявок.</div>';
    }

    return fyremezzonine_manager_partner_requests_interface(false);
}
add_shortcode('conference_partner_requests_archive', 'fyremezzonine_manager_partner_requests_shortcode');

function fyremezzonine_manager_render_frontend_editor_page($title, $content, $eyebrow = 'Редактор') {
    global $wp_query;

    if ($wp_query) {
        $wp_query->is_404 = false;
    }

    status_header(200);
    get_header();
    ?>
    <main id="primary">
        <section class="section editor-page">
            <div class="section-inner page-layout">
                <p class="section-eyebrow"><?php echo esc_html($eyebrow); ?></p>
                <h1 class="section-title"><?php echo esc_html($title); ?></h1>
                <?php echo do_shortcode($content); ?>
            </div>
        </section>
    </main>
    <?php
    get_footer();
    exit;
}

function fyremezzonine_manager_render_conference_preview() {
    global $post, $wp_query;

    $conference_id = isset($_GET['conference_id']) ? absint($_GET['conference_id']) : 0;
    $conference = $conference_id ? get_post($conference_id) : null;

    if (!$conference || $conference->post_type !== 'conference') {
        fyremezzonine_manager_render_frontend_editor_page('Предпросмотр конференции', '<div class="registration-message registration-error">Конференция не найдена.</div>');
    }

    if (!is_user_logged_in()) {
        fyremezzonine_manager_render_frontend_editor_page('Предпросмотр конференции', '<div class="registration-message registration-error">Войдите в WordPress, чтобы посмотреть черновик конференции.</div>');
    }

    if (!current_user_can('edit_post', $conference_id)) {
        fyremezzonine_manager_render_frontend_editor_page('Предпросмотр конференции', '<div class="registration-message registration-error">У вашей учетной записи нет прав для просмотра этого черновика.</div>');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fyremezzonine_preview_publish_nonce'])) {
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fyremezzonine_preview_publish_nonce'])), 'fyremezzonine_preview_publish_' . $conference_id)) {
            fyremezzonine_manager_render_frontend_editor_page('Предпросмотр конференции', '<div class="registration-message registration-error">Не удалось проверить публикацию. Обновите предпросмотр и попробуйте еще раз.</div>');
        }

        $published_id = wp_update_post(
            array(
                'ID' => $conference_id,
                'post_status' => 'publish',
            ),
            true
        );

        if (is_wp_error($published_id)) {
            fyremezzonine_manager_render_frontend_editor_page('Предпросмотр конференции', '<div class="registration-message registration-error">Конференцию не удалось опубликовать. Вернитесь к редактированию и попробуйте еще раз.</div>');
        }

        wp_safe_redirect(get_permalink($conference_id));
        exit;
    }

    status_header(200);
    nocache_headers();

    $post = $conference;
    setup_postdata($post);

    $wp_query = new WP_Query();
    $wp_query->posts = array($conference);
    $wp_query->post_count = 1;
    $wp_query->current_post = -1;
    $wp_query->in_the_loop = false;
    $wp_query->queried_object = $conference;
    $wp_query->queried_object_id = $conference_id;
    $wp_query->is_single = true;
    $wp_query->is_singular = true;
    $wp_query->is_preview = true;
    $wp_query->is_404 = false;

    $GLOBALS['fyremezzonine_manager_preview_conference_id'] = $conference_id;
    add_action('wp_body_open', 'fyremezzonine_manager_render_preview_toolbar');

    $template = locate_template('single-conference.php');
    if ($template) {
        include $template;
        exit;
    }

    fyremezzonine_manager_render_frontend_editor_page(
        'Предпросмотр конференции',
        '<div class="registration-message registration-error">Шаблон конференции не найден в активной теме.</div>'
    );
}

function fyremezzonine_manager_render_preview_toolbar() {
    $conference_id = !empty($GLOBALS['fyremezzonine_manager_preview_conference_id']) ? absint($GLOBALS['fyremezzonine_manager_preview_conference_id']) : 0;
    if (!$conference_id || !current_user_can('edit_post', $conference_id)) {
        return;
    }

    $status = get_post_status($conference_id);
    $status_object = $status ? get_post_status_object($status) : null;
    $status_label = $status_object ? $status_object->label : $status;
    $edit_url = add_query_arg('conference_id', $conference_id, fyremezzonine_manager_editor_page_url('edit-conference'));
    ?>
    <div class="conference-preview-toolbar">
        <div>
            <strong>Предпросмотр конференции</strong>
            <span>Статус: <?php echo esc_html($status_label); ?></span>
        </div>
        <div class="conference-preview-toolbar-actions">
            <a class="button button-outline" href="<?php echo esc_url($edit_url); ?>">Редактировать</a>
            <?php if ($status !== 'publish') : ?>
                <form method="post" action="<?php echo esc_url(fyremezzonine_manager_conference_preview_url($conference_id)); ?>">
                    <?php wp_nonce_field('fyremezzonine_preview_publish_' . $conference_id, 'fyremezzonine_preview_publish_nonce'); ?>
                    <button class="button button-red" type="submit">Опубликовать конференцию</button>
                </form>
            <?php else : ?>
                <a class="button button-red" href="<?php echo esc_url(get_permalink($conference_id)); ?>">Открыть опубликованную</a>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function fyremezzonine_manager_frontend_editor_routes() {
    $path = isset($_SERVER['REQUEST_URI']) ? trim((string) wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH), '/') : '';

    if ($path === 'partnership') {
        fyremezzonine_manager_render_frontend_editor_page('Заявка на партнерство', '[conference_partner_request_form]', 'Партнерство');
    }

    if ($path === 'editor/new-conference') {
        fyremezzonine_manager_render_frontend_editor_page('Создать конференцию', '[conference_submission_form]');
    }

    if ($path === 'editor/edit-conference') {
        fyremezzonine_manager_render_frontend_editor_page('Изменить конференцию', '[conference_submission_form]');
    }

    if ($path === 'editor/conference-preview') {
        fyremezzonine_manager_render_conference_preview();
    }

    if ($path === 'editor/registrations') {
        fyremezzonine_manager_render_frontend_editor_page('Заявки на конференции', '[conference_registrations_archive]');
    }

    if ($path === 'editor/partner-requests') {
        fyremezzonine_manager_render_frontend_editor_page('Заявки на партнерство', '[conference_partner_requests_archive]');
    }
}
add_action('template_redirect', 'fyremezzonine_manager_frontend_editor_routes');

function fyremezzonine_manager_render_guide_page() {
    ?>
    <div class="wrap">
        <h1>Как редактировать сайт конференций</h1>
        <p>Главная страница автоматически показывает ближайшую будущую конференцию: берется опубликованная конференция с минимальной датой начала, которая не меньше сегодняшней даты.</p>
        <h2>Где менять контент</h2>
        <ol>
            <li>Откройте <strong>Конференции -> Все конференции</strong>.</li>
            <li>Выберите конференцию или нажмите <strong>Добавить конференцию</strong>.</li>
            <li>Заполните название, описание, краткое описание и блок <strong>Данные конференции</strong>.</li>
            <li>Для картинок используйте кнопку <strong>Выбрать файл</strong> в нужном поле конференции.</li>
            <li>Для карты укажите понятный адрес площадки в поле <strong>Адрес для карты/маршрута</strong>.</li>
        </ol>
        <h2>Упрощенная форма для редактора</h2>
        <p>На сайте после входа редактора откройте меню <strong>Редактор -> Создать конференцию</strong>. Это форма в стиле анкеты: она создает конференцию без работы с обычным редактором WordPress. Адрес страницы: <code>/editor/new-conference/</code>.</p>
        <h2>Что управляется из карточки конференции</h2>
        <p>Дата, город, место, дедлайн, ссылка на программу, первый экран, темы, изображения тем, блок "О конференции", преимущества, партнеры и спонсоры, место проведения, маршрут, карта и галерея.</p>
        <h2>Где смотреть заявки</h2>
        <p>На сайте после входа редактора откройте <strong>Редактор -> Заявки и экспорт</strong>. Там можно выбрать конференцию, посмотреть архив старых регистраций и выгрузить Excel. Данные хранятся в таблице <code>wp_conference_registrations</code>.</p>
    </div>
    <?php
}

function fyremezzonine_manager_render_registrations_page() {
    ?>
    <div class="wrap">
        <h1>Заявки на конференции</h1>
        <?php echo fyremezzonine_manager_registrations_interface(true); ?>
    </div>
    <?php
}

function fyremezzonine_manager_render_partner_requests_page() {
    ?>
    <div class="wrap">
        <h1>Заявки на партнерство</h1>
        <?php echo fyremezzonine_manager_partner_requests_interface(true); ?>
    </div>
    <?php
}
